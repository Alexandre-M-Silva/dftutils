# dftutils

This is a collection of utilities for the setup & post processing of DFT calculations using VASP.   